--XPoblar--

DELETE FROM ProductModelProductDescription;
DELETE FROM ProductDescription;
DELETE FROM SalesOrderDetail;
DELETE FROM Product;
DELETE FROM ProductModel;
DELETE FROM ProductCategory;
DELETE FROM SalesOrderHeader;
DELETE FROM CustomerAddress;
DELETE FROM Address;
DELETE FROM Customer;