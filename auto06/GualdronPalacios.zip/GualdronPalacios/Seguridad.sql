GRANT EXECUTE
    ON PA_Administrador
TO Administrador;

GRANT EXECUTE
    ON PA_Cliente
TO Cliente;