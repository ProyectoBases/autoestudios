REVOKE ALL ON PA_Administrador FROM Administrador;
REVOKE ALL ON PA_Cliente FROM Cliente;

