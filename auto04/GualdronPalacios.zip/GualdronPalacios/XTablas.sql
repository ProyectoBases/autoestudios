--XTablas--

DROP TABLE ProductModelProductDescription;
DROP TABLE ProductDescription;
DROP TABLE SalesOrderDetail;
DROP TABLE Product;
DROP TABLE ProductModel;
DROP TABLE ProductCategory;
DROP TABLE SalesOrderHeader;
DROP TABLE CustomerAddress;
DROP TABLE Address;
DROP TABLE Customer;