--CATEGORIAS--

INSERT INTO ProductCategory(ProductCategoryID,ParentProductCategoryID,Name) VALUES(42,NULL,'Pants'); 
INSERT INTO ProductCategory(ProductCategoryID,ParentProductCategoryID,Name) VALUES(43,NULL,'Kneepads'); 
INSERT INTO ProductCategory(ProductCategoryID,ParentProductCategoryID,Name) VALUES(44,NULL,'Heel');


--MODELOS--

INSERT INTO ProductModel(ProductModelID,Name,CatalogDescription) VALUES(132,'HL Touring',NULL); 
INSERT INTO ProductModel(ProductModelID,Name,CatalogDescription) VALUES(133,'LL Road Front',NULL); 
INSERT INTO ProductModel(ProductModelID,Name,CatalogDescription) VALUES(134,'ML Road Front',NULL);