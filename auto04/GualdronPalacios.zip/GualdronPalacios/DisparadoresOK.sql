--CATEGORIAS--

INSERT INTO ProductCategory(ParentProductCategoryID, Name) VALUES(NULL,'Pants'); 
INSERT INTO ProductCategory(ParentProductCategoryID, Name) VALUES(NULL,'Kneepads'); 
INSERT INTO ProductCategory(ParentProductCategoryID, Name) VALUES(NULL,'Heel'); 


--MODELOS--

INSERT INTO ProductModel(Name,CatalogDescription) VALUES('HL Touring',NULL); 
INSERT INTO ProductModel(Name,CatalogDescription) VALUES('LL Road Front',NULL); 
INSERT INTO ProductModel(Name,CatalogDescription) VALUES('ML Road Front',NULL);